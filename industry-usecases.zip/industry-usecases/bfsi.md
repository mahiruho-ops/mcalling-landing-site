# BFSI Use Cases — MChatbot (Marketing-Ready)

- **Audience**: Banks, NBFCs, Insurers, Fintech, CX/Support, Marketing, Collections, Risk/Compliance
- **Goal**: Acquire & qualify, verify KYC, service accounts/policies, automate claims/loans/cards, reduce fraud & call load
- **Template**: BFSI Template Agent (from Template Agents)

## Quick Pitch
“Acquire, verify, and service customers across Web/WhatsApp/IVR — account opening, KYC, loans/cards, premiums/claims — with compliant guardrails and full audit.”

## Key Outcomes to Promote
- Faster onboarding (pre‑qualified + KYC assist)
- Lower call volume via self‑serve servicing
- Higher conversion for loans/cards/policies
- Proactive collections and fraud mitigation

## Building Blocks (simple)
- **Template Agent**: The brain (tone + model + product/policy knowledge + compliance)
- **Node Libraries**: Plug‑in blocks (Core Banking/Policy Admin, KYC/AML/CKYC, Credit Bureau, Payments, CRM, Risk/Fraud)
- **Bot**: Connects the Agent to channels (Web, WhatsApp, IVR, SMS)
- **Workflow**: After‑chat automations (e‑sign/e‑mandate, emails, tickets, webhooks, audits)

## Node Libraries (pick what you need)
- **Agent Nodes**
  - Knowledge Base Connector (products, eligibility, fees, claims steps)
  - Core Banking/Policy Admin Connector (balances, policies, endorsements)
  - KYC/AML/CKYC Connector (ID verify, liveness), Credit Bureau Connector
  - Payments Connector (premiums/EMIs), e‑Sign/e‑Mandate
  - Risk/Fraud Engine Connector (rules/flags), Consent/Privacy Node
  - Guardrail Policy (regulated copy), Human Handoff, Memory Store
- **Channel Nodes**
  - Web Chat, WhatsApp, IVR/Voice, SMS
- **Workflow Nodes**
  - Email/SMS/WhatsApp Notify, Webhook/HTTP Post, Ticket Create (helpdesk)
  - CRM Update, Collections Broadcast, Audit Log, Survey (CSAT/NPS)

---

## Campaign‑Ready Use Case Stories (full flow)
Each: Trigger → Agents → Node Libraries → Bot (channels) → Workflow → Sample chat → Highlight.

### A) Account Opening & KYC Assist (Acquisition)
- **Trigger**: “Open account” on Web/WhatsApp
- **Agents**: BFSI Template Agent
- **Node Libraries**:
  - KYC/CKYC Connector (ID capture/verify)
  - Core Banking Connector (lead/account create)
  - Consent/Privacy Node, e‑Sign
- **Bot (Channels)**: Web + WhatsApp
- **Workflow**:
  1) Explain options → 2) Capture KYC → 3) Verify → 4) Create account/lead → 5) Send welcome pack
- **Sample chat**:
  - Prospect: “Open zero‑balance account.”
  - Agent: “Upload ID. Liveness check… Verified. Account created.”
- **Highlight**: “Friction‑lite onboarding.”

### B) Loan/Card Pre‑qualification (Conversion)
- **Trigger**: “Am I eligible?”
- **Agents**: BFSI Template Agent
- **Node Libraries**:
  - Credit Bureau Connector (score/bands)
  - CRM Connector (pre‑app)
  - Guardrail Policy (disclaimer)
- **Bot (Channels)**: Web + WhatsApp
- **Workflow**:
  1) Capture basics → 2) Pull credit band → 3) Show options → 4) Create pre‑app → 5) Book pickup/e‑sign
- **Sample chat**:
  - Prospect: “Need ₹3L personal loan.”
  - Agent: “Likely eligible for 2.5–3L. Proceed to pre‑app?”
- **Highlight**: “Clear next steps. Better conversions.”

### C) Balance, Statements & Limits (Service)
- **Trigger**: “Statement for Aug” / “Increase limit”
- **Agents**: BFSI Template Agent
- **Node Libraries**:
  - Core Banking Connector (balances/statements)
  - Card System Connector (limits)
  - Notifications (email PDF)
- **Bot (Channels)**: WhatsApp + IVR + Web
- **Workflow**:
  1) Verify OTP → 2) Fetch/share → 3) If limit change, create request → 4) Notify
- **Sample chat**:
  - Customer: “Share Aug statement.”
  - Agent: “Sent to email. Anything else?”
- **Highlight**: “Self‑serve that customers love.”

### D) Insurance Policy Service & Premiums (Care)
- **Trigger**: “Due date?” / “Change address” / “Premium receipt?”
- **Agents**: BFSI Template Agent
- **Node Libraries**:
  - Policy Admin Connector, Payments Connector
  - Document Request (endorsement docs)
- **Bot (Channels)**: Web + WhatsApp + IVR
- **Workflow**:
  1) Fetch policy → 2) Take request → 3) Collect payment/docs → 4) Update policy → 5) Share receipt
- **Sample chat**:
  - Customer: “Pay premium now.”
  - Agent: “Link sent. Receipt will follow.”
- **Highlight**: “Reduce call time. Improve renewals.”

### E) Claims FNOL & Status (P&C)
- **Trigger**: “Report claim” / webhook from app
- **Agents**: BFSI Template Agent → Claims Agent (optional)
- **Node Libraries**:
  - Document Capture (photos), Location (incident), Policy Admin (coverage)
  - Ticket Create (claim case)
- **Bot (Channels)**: WhatsApp + Web + IVR
- **Workflow**:
  1) Capture incident → 2) Verify coverage → 3) Create case → 4) Share checklist → 5) Status updates
- **Sample chat**:
  - Customer: “Rear bump, minor dent.”
  - Agent: “Claim created. Upload photos. Garage partner list sent.”
- **Highlight**: “Fast FNOL, fewer frustrations.”

### F) Fraud Alert & Transaction Dispute (Risk)
- **Trigger**: “Unknown debit” or rule hit
- **Agents**: BFSI Template Agent → Risk Agent
- **Node Libraries**:
  - Risk/Fraud Engine Connector
  - Card System Connector (block/replace)
  - Ticket Create (dispute)
- **Bot (Channels)**: WhatsApp + IVR + Web
- **Workflow**:
  1) Verify customer → 2) Block card if needed → 3) Create dispute → 4) Notify progress
- **Sample chat**:
  - Customer: “Not my charge.”
  - Agent: “Card blocked. Dispute #D129 opened.”
- **Highlight**: “Contain fraud quickly.”

### G) Collections & Reminders (Proactive)
- **Trigger**: DPD‑based outreach
- **Agents**: BFSI Template Agent
- **Node Libraries**:
  - Collections Broadcast, Payments Connector
  - CRM Update
- **Bot (Channels)**: WhatsApp + SMS + IVR
- **Workflow**:
  1) Notify due → 2) Offer payment plan → 3) Take payment → 4) Update CRM
- **Sample chat**:
  - Agent: “EMI due in 3 days. Pay now or set a plan?”
- **Highlight**: “Gentle nudges, better recovery.”

### H) Wealth & Advisory FAQs (Guardrailed)
- **Trigger**: “Debt fund vs fixed deposit?”
- **Agents**: BFSI Template Agent
- **Node Libraries**:
  - Knowledge Base (approved content)
  - Guardrail Policy (no personalized advice; disclaimers)
  - CRM Connector (log interest)
- **Bot (Channels)**: Web + WhatsApp
- **Workflow**:
  1) Provide approved info → 2) Log interest → 3) Offer human advisor
- **Sample chat**:
  - Investor: “FD vs debt?”
  - Agent: “Here are approved differences. For advice, I can connect you to an advisor.”
- **Highlight**: “Education without compliance risk.”

---

## Social‑Ready Assets
- **Hooks**
  - “Open, verify, and serve — in chat.”
  - “Claims without call queues.”
  - “Fraud handled in minutes.”
- **One‑liners**
  - “Banking and insurance, made conversational.”
  - “More conversions, fewer calls.”
  - “Compliant by design.”
- **Visual ideas**
  - Flow: Trigger → Agent → Nodes → Bot → Workflow → KPI
  - FNOL card: photos → checklist → status
  - Fraud: alert → block → dispute
- **CTAs**
  - “Try the BFSI Template Agent”
  - “See KYC + onboarding in 60 seconds”
  - “Talk to us about core/claims integrations”

## Compliance Notes
- Use regulated copy and approved disclaimers.
- Always capture consent; log all changes (audit).
- Mask PII; avoid sharing sensitive data on open channels.

## KPIs to Feature
- Onboarding time, self‑serve resolution %, claim cycle time, fraud containment time, CSAT/renewals.

## Build in 5 Steps (recap)
1) Create BFSI Template Agent
2) Add Agent Nodes (Core/KYC/Credit, Payments, Risk, Guardrail, Memory)
3) Create Bot (connect Web/WhatsApp/IVR/SMS)
4) Add Workflow (e‑sign, notifications, tickets, audits)
5) Launch pilot; measure and iterate

## Outcomes (headline copy)
- **Customers**: Faster answers, simpler service, safer banking/insurance
- **Teams**: Fewer calls, faster cycles, cleaner compliance trails
