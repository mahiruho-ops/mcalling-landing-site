# E-commerce Use Cases — MChatbot (Marketing-Ready)

- **Audience**: D2C Brands, Ecommerce/Marketplace Teams, Growth/CRM, CX, Store Ops, Marketing
- **Goal**: Boost conversion/AOV, recover carts, reduce support load, streamline returns/pickups, grow subscriptions/LTV
- **Template**: E-commerce Template Agent (from Template Agents)

## Quick Pitch
“Convert visitors with guided selling, recover carts, track orders, and manage returns/subscriptions across Web, WhatsApp, SMS, and social — with enterprise guardrails.”

## Key Outcomes to Promote
- +8–22% conversion uplift with guided selling
- +5–15% AOV via bundles/upsells/cross-sells
- 20–40% ticket deflection (post‑purchase self‑serve)
- Faster returns/BOPIS, higher LTV via subscriptions

## Building Blocks (simple)
- **Template Agent**: The brain (tone + model + catalog/brand knowledge + policies)
- **Node Libraries**: Plug‑in blocks (Commerce, Inventory/PIM, Payments, Shipping/Carriers, RMA, CRM/CDP, Subscriptions)
- **Bot**: Connects the Agent to channels (Web, WhatsApp, SMS, Instagram/FB DM, Kiosk)
- **Workflow**: After‑chat automations (emails, order/RMA updates, webhooks, tickets)

## Node Libraries (pick what you need)
- **Agent Nodes**
  - Knowledge Base Connector (size charts, care, policies, brand tones)
  - Commerce Platform Connector (Shopify/Magento/Custom)
  - Inventory/PIM Connector (variants/stock)
  - Recommender (related, bundles, complements)
  - Promotions/Pricing (codes, offers)
  - Subscriptions Connector (create/pause/skip/change)
  - Returns/RMA Connector
  - Payment Capture (checkout link)
  - Memory Store, Guardrail Policy, Human Handoff
- **Channel Nodes**
  - Web Chat, WhatsApp, SMS, Instagram/FB Messenger, Kiosk/Tablet
- **Workflow Nodes**
  - Email/SMS/WhatsApp Notify, Webhook/HTTP Post
  - Order Management, RMA/Returns, Shipment/Carrier, Store Locator/Appointment
  - Ticket Create, Survey (CSAT/NPS), Audit Log

---

## Campaign‑Ready Use Case Stories (full flow)
Each: Trigger → Agents → Node Libraries → Bot (channels) → Workflow → Sample chat → Highlight.

### A) Guided Selling & Bundles (Top‑funnel → Conversion)
- **Trigger**: Website “Ask for advice” or Instagram DM QR
- **Agents**: E-commerce Template Agent
- **Node Libraries**:
  - Knowledge Base (size/care)
  - Recommender (bundle/cross‑sell)
  - Commerce Connector (add to cart)
  - Promotions (apply code)
- **Bot (Channels)**: Web + Instagram DM + WhatsApp
- **Workflow**:
  1) Ask use case → 2) Recommend set/bundle → 3) Add to cart → 4) Apply promo → 5) Share checkout link → 6) Reminder
- **Sample chat**:
  - Shopper: “Gift set for ₹2,000 budget.”
  - Agent: “This bundle fits. Add and apply FEST10?”
- **Highlight**: “From chat to cart, ready to pay.”

### B) Preorder & Back‑in‑Stock Alerts (Conversion rescue)
- **Trigger**: “Notify when back” / preorder page
- **Agents**: E-commerce Template Agent
- **Node Libraries**:
  - Inventory Connector (stock events)
  - Broadcast/Notify (segment)
  - Promotions (limited code)
- **Bot (Channels)**: WhatsApp + Email
- **Workflow**:
  1) Capture interest → 2) Notify restock → 3) Apply limited offer → 4) Checkout link → 5) Track conversions
- **Sample chat**:
  - Agent: “Your size is back. 10% off for 24h. Buy now?”
- **Highlight**: “Turn waitlists into wins.”

### C) Cart Recovery & Offer Nurture (Revenue rescue)
- **Trigger**: Abandoned cart webhook
- **Agents**: E-commerce Template Agent
- **Node Libraries**:
  - Commerce Connector (cart items)
  - Promotions (targeted code)
  - Recommender (complements)
- **Bot (Channels)**: WhatsApp + Email + SMS
- **Workflow**:
  1) Send reminder → 2) Offer incentive → 3) Rebuild cart → 4) Share checkout → 5) Track conversions
- **Sample chat**:
  - Agent: “Still eyeing the tote? Extra 5% off today. Rebuild cart?”
  - Shopper: “Yes.”
- **Highlight**: “Gentle nudge. Real revenue.”

### D) Order Tracking & Exception Handling (Care)
- **Trigger**: “Track #A1276” on WhatsApp/Web
- **Agents**: E-commerce Template Agent
- **Node Libraries**:
  - Order Management + Shipment/Carrier Connectors
  - Notifications (exceptions)
- **Bot (Channels)**: WhatsApp + Web + SMS
- **Workflow**:
  1) Verify order → 2) Show live status/ETA → 3) Notify delays → 4) Offer support → 5) Log audit
- **Sample chat**:
  - Shopper: “Where’s my order?”
  - Agent: “Out for delivery. ETA 6–8 PM.”
- **Highlight**: “Deflects WISMO tickets.”

### E) Returns/RMA & Exchanges (Care + Retention)
- **Trigger**: “Return/exchange order”
- **Agents**: E-commerce Template Agent
- **Node Libraries**:
  - RMA/Returns Connector
  - Recommender (exchange suggestions)
  - Promotions (credit/retention)
- **Bot (Channels)**: Web + WhatsApp
- **Workflow**:
  1) Validate item → 2) Offer exchange/credit → 3) Create RMA + pickup label → 4) Notify status
- **Sample chat**:
  - Shopper: “Size too small.”
  - Agent: “Exchange to M? Free pickup arranged.”
- **Highlight**: “Save the sale with exchanges.”

### F) BOPIS/Store Pickup & Appointments (Omnichannel)
- **Trigger**: Order with store pickup / “Nearest store with size M”
- **Agents**: E-commerce Template Agent
- **Node Libraries**:
  - Store Locator/Inventory
  - Appointment/Scheduler
- **Bot (Channels)**: Web + WhatsApp + Kiosk
- **Workflow**:
  1) Find nearby stock → 2) Hold item → 3) Book pickup/try‑on → 4) Send directions → 5) Remind
- **Sample chat**:
  - Agent: “Available at Phoenix Mall. Hold and book 6 PM?”
- **Highlight**: “Clicks that become footfalls.”

### G) Subscription Management (LTV)
- **Trigger**: “Pause/Skip/Change subscription”
- **Agents**: E-commerce Template Agent
- **Node Libraries**:
  - Subscriptions Connector (pause/skip/change)
  - Promotions (retain on downgrade)
- **Bot (Channels)**: Web + WhatsApp + Email
- **Workflow**:
  1) Verify customer → 2) Apply change → 3) Offer retain promo → 4) Confirm
- **Sample chat**:
  - Shopper: “Skip next month’s box.”
  - Agent: “Skipped. Want 10% off if you keep it?”
- **Highlight**: “Save churn in the moment.”

### H) UGC Q&A & Moderation (Trust)
- **Trigger**: “Question about fit/material”
- **Agents**: E-commerce Template Agent
- **Node Libraries**:
  - Knowledge Base (approved answers)
  - Moderation Guardrail (block risky terms)
  - CRM/CDP (log interest)
- **Bot (Channels)**: Web + Instagram DM
- **Workflow**:
  1) Provide approved answer → 2) Log interest → 3) Offer guided selling
- **Sample chat**:
  - Shopper: “Is it machine washable?”
  - Agent: “Yes — cold wash. Want matching pants?”
- **Highlight**: “Trust boosts conversion.”

---

## Social‑Ready Assets
- **Hooks**
  - “From DM to checkout — in one flow.”
  - “Returns that retain.”
  - “Subscriptions that don’t churn.”
- **One‑liners**
  - “Guided shopping that converts.”
  - “Post‑purchase care, automated.”
  - “Omnichannel that actually works.”
- **Visual ideas**
  - Chat to cart: rec → promo → checkout link
  - Restock alert card: notify → code → buy
  - Returns card: exchange → pickup label → status
- **CTAs**
  - “Try the E‑commerce Template Agent”
  - “See guided selling in 60 seconds”
  - “Talk to us about Shopify/Magento integrations”

## Compliance Notes
- Transparent pricing/promo terms; avoid overpromising stock/ETAs.
- Respect opt‑in/opt‑out on each channel.
- Don’t store card data; use payment gateway flows.

## KPIs to Feature
- Conversion rate, AOV, cart recovery rate, first response time, CSAT/NPS, return‑to‑exchange save rate.

## Build in 5 Steps (recap)
1) Create E‑commerce Template Agent
2) Add Agent Nodes (KB, Commerce/Inventory, Recommender, Promotions, Subscriptions, Guardrail, Memory)
3) Create Bot (connect Web/WhatsApp/SMS/DM)
4) Add Workflow (order/RMA updates, notifications, tickets, survey)
5) Launch pilot; measure and iterate

## Outcomes (headline copy)
- **Shoppers**: Helpful guidance, quick support, easy returns, fast pickup
- **Teams**: Fewer tickets, higher conversions, smoother operations, better loyalty
