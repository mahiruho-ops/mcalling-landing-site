# Education Use Cases — MChatbot (Marketing-Ready)

- **Audience**: Universities, Colleges, EdTech, Admissions, Student Services, Registrar, Placement, Marketing
- **Goal**: Increase applications/enrolments, reduce query load, improve student support, streamline fees/exams/placements
- **Template**: Education Template Agent (from Template Agents)

## Quick Pitch
“Answer admissions queries, guide applications, remind fees/exams, and support students on WhatsApp/Web/IVR — connected to SIS/LMS and with enterprise controls.”

## Key Outcomes to Promote
- +10–30% application completion (guided journeys)
- 30–50% reduction in call/email volume (self‑serve)
- Fewer missed deadlines (smart reminders)
- Better student satisfaction and placement coordination

## Building Blocks (simple)
- **Template Agent**: The brain (tone + model + program/academic knowledge + policies)
- **Node Libraries**: Plug‑in blocks (SIS/CRM, LMS, Payments, Scheduler, Notifications)
- **Bot**: Connects the Agent to channels (Web, WhatsApp, SMS, IVR, Email)
- **Workflow**: After‑chat automations (emails, SIS/LMS updates, tickets, reminders)

## Node Libraries (pick what you need)
- **Agent Nodes**
  - Knowledge Base Connector (programs, eligibility, deadlines, rules)
  - SIS/Admissions CRM Connector (apply status, documents)
  - LMS Connector (courses, assignments, grades)
  - Payments Connector (fees, receipts)
  - Scheduler/Calendar (timetables, slots)
  - Memory Store (student context; retention rules)
  - Guardrail Policy (policy compliance; escalation)
  - Human Handoff (counsellor/helpdesk)
- **Channel Nodes**
  - Web Chat, WhatsApp, SMS, IVR/Voice, Email
- **Workflow Nodes**
  - Email Trigger, SMS/WhatsApp Notify, Webhook/HTTP Post
  - SIS/LMS Update, Document Request, Survey (CSAT), Audit Log

---

## Campaign‑Ready Use Case Stories (full flow)
Each example: Trigger → Agents → Node Libraries → Bot (channels) → Workflow → Sample chat → Highlight.

### A) Program Discovery & Counselling (Top‑funnel → Application)
- **Trigger**: “Find the right program” on website/WhatsApp
- **Agents**: Education Template Agent
- **Node Libraries**:
  - Knowledge Base Connector (programs, eligibility)
  - SIS/Admissions CRM Connector (lead + pre‑app)
  - Scheduler (counsellor slot)
- **Bot (Channels)**: Web + WhatsApp
- **Workflow**:
  1) Gather interest/eligibility → 2) Recommend programs → 3) Create lead → 4) Book counselling → 5) Send checklist
- **Sample chat**:
  - Aspirant: “Looking for MBA with analytics.”
  - Agent: “MBA (BA) & PGDM (DS) fit. Shall I book a counsellor for tomorrow 4 PM?”
- **Highlight**: “From curiosity to intent in one flow.”

### B) Application Guidance & Document Checklist (Conversion)
- **Trigger**: Start application link or QR at campus fair
- **Agents**: Education Template Agent
- **Node Libraries**:
  - Admissions CRM Connector (application create/status)
  - Document Request Node (uploads)
  - Email Trigger (reminders)
- **Bot (Channels)**: Web + WhatsApp + Email
- **Workflow**:
  1) Create app → 2) Share stepwise checklist → 3) Remind pending docs → 4) Confirm submission
- **Sample chat**:
  - Agent: “Pending: transcript & photo. Upload now?”
  - Aspirant: “Uploaded.”
- **Highlight**: “Higher completion, fewer back‑and‑forths.”

### C) Fees, Receipts & Scholarships (Care + Finance)
- **Trigger**: “Fee due?” / “Receipt?” / “Scholarship status?”
- **Agents**: Education Template Agent
- **Node Libraries**:
  - Payments Connector (due, receipt)
  - SIS Connector (scholarship status)
  - Notifications (reminders)
- **Bot (Channels)**: WhatsApp + Web
- **Workflow**:
  1) Fetch dues → 2) Share payment link → 3) Send receipt → 4) Remind before deadline
- **Sample chat**:
  - Student: “Share my receipt for Term 2.”
  - Agent: “Sent to your email & WhatsApp.”
- **Highlight**: “Fewer queues, cleaner records.”

### D) Timetables, Exams & Results (Ops)
- **Trigger**: “Tomorrow’s timetable?” / “Exam center?” / “Result?”
- **Agents**: Education Template Agent
- **Node Libraries**:
  - Scheduler/Calendar (timetable, exam)
  - LMS/SIS Connector (results)
- **Bot (Channels)**: WhatsApp + Web + IVR
- **Workflow**:
  1) Fetch info → 2) Share details → 3) Set reminder → 4) Log audit
- **Sample chat**:
  - Student: “When is the DS exam?”
  - Agent: “June 18, 10 AM, Hall B2. Want a 24h reminder?”
- **Highlight**: “Students stay on track.”

### E) Attendance Follow‑ups (Retention)
- **Trigger**: Low attendance detected (Webhook)
- **Agents**: Education Template Agent
- **Node Libraries**:
  - SIS Connector (attendance)
  - Broadcast/Notify (guardian copy optional)
- **Bot (Channels)**: WhatsApp + SMS + Email
- **Workflow**:
  1) Notify shortfall → 2) Share steps to improve → 3) Offer counsellor slot → 4) Track acknowledgements
- **Sample chat**:
  - Agent: “Attendance at 61%. Shall I book a counsellor?”
- **Highlight**: “Saves drop‑outs.”

### F) LMS Helpdesk & Resets (Care)
- **Trigger**: “Forgot LMS password” / “Can’t see course”
- **Agents**: Education Template Agent → IT Helpdesk
- **Node Libraries**:
  - LMS Connector (account lookup)
  - Ticket Create (helpdesk)
  - Human Handoff (IT)
- **Bot (Channels)**: Web + WhatsApp
- **Workflow**:
  1) Verify → 2) Self‑serve reset if eligible → 3) Else create ticket → 4) Notify updates
- **Sample chat**:
  - Student: “Can’t access Data Mining.”
  - Agent: “Enrolment missing — I’ll create a ticket and notify you.”
- **Highlight**: “First‑contact resolution where possible.”

### G) Placement Cell Coordination (Career)
- **Trigger**: Campus drive announcement
- **Agents**: Education Template Agent → Placement Agent (optional)
- **Node Libraries**:
  - Broadcast/Notify (eligible batch)
  - Document Request (resume updates)
  - Scheduler (interview slots)
- **Bot (Channels)**: WhatsApp + Email
- **Workflow**:
  1) Notify eligible → 2) Collect resumes → 3) Book slots → 4) Send reminders → 5) Feedback
- **Sample chat**:
  - Agent: “Slots open Wed/Fri. Book now?”
- **Highlight**: “Organized drives, better outcomes.”

### H) Alumni Engagement (Community)
- **Trigger**: Reunion/event or mentorship drive
- **Agents**: Education Template Agent
- **Node Libraries**:
  - CRM/Alumni Connector (segments)
  - Broadcast/Notify, Survey (interest)
  - Donation/Payment Node (optional)
- **Bot (Channels)**: Email + WhatsApp
- **Workflow**:
  1) Invite → 2) Capture interest → 3) Confirm attendance → 4) Share logistics → 5) Post‑event survey
- **Sample chat**:
  - Agent: “Join the mentorship circle this Saturday?”
- **Highlight**: “Keeps the network active.”

---

## Social‑Ready Assets
- **Hooks**
  - “Admissions queries answered in minutes.”
  - “Never miss fees or exams again.”
  - “Placement drives, organized in chat.”
- **One‑liners**
  - “Student support that scales.”
  - “From inquiry to enrolment — guided.”
  - “Academic ops, automated.”
- **Visual ideas**
  - Flow: Trigger → Agent → Nodes → Bot → Workflow → KPI
  - Timeline: application → checklist → reminders → submission
  - WhatsApp mock: timetable reminder card
- **CTAs**
  - “Try the Education Template Agent”
  - “See admissions guidance in 60 seconds”
  - “Talk to us about SIS/LMS integrations”

## Compliance Notes
- Keep student PII minimal; mask sensitive fields.
- Respect consent/opt‑in for guardians and channels.
- Use approved policy language in answers.

## KPIs to Feature
- Application completion, response time, call deflection, attendance adherence, CSAT.

## Build in 5 Steps (recap)
1) Create Education Template Agent
2) Add Agent Nodes (KB, SIS/LMS, Payments/Scheduler, Guardrail, Memory)
3) Create Bot (connect Web/WhatsApp/SMS/IVR)
4) Add Workflow (notifications, SIS/LMS updates, tickets, surveys)
5) Launch pilot; measure and iterate

## Outcomes (headline copy)
- **Students**: Quick answers, fewer misses, smoother support
- **Teams**: Fewer calls, better adherence, organized operations
