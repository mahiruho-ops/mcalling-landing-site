# e‑Govt. / Citizen Services Use Cases — MChatbot (Marketing-Ready)

- **Audience**: Government Departments, Municipalities, Utilities, Transport, Tax Boards, Public Health, Citizen Helplines
- **Goal**: Reduce counter/phone load, 24×7 self‑service, faster case resolution, transparent updates, multilingual access
- **Template**: Citizen Services Template Agent (from Template Agents)

## Quick Pitch
“File grievances, pay bills/taxes, apply for permits/certificates, and get multilingual updates on WhatsApp/Web/IVR — connected to core systems, with SLAs and audit trails.”

## Key Outcomes to Promote
- 30–60% call/counter reduction
- Faster service resolution and SLA adherence
- Higher citizen satisfaction via proactive updates
- Inclusive access (multilingual, IVR, WhatsApp)

## Building Blocks (simple)
- **Template Agent**: The brain (tone + model + schemes/services/FAQs + policies)
- **Node Libraries**: Plug‑in blocks (Case Mgmt., Payments, ID/KYC, GIS/Location, Scheduler, Docs, Notifications)
- **Bot**: Connects the Agent to channels (WhatsApp, Web Chat, IVR/Voice, SMS)
- **Workflow**: After‑chat automations (tickets, submissions, payments, escalations, audits)

## Node Libraries (pick what you need)
- **Agent Nodes**
  - Knowledge Base Connector (schemes, eligibility, documents)
  - Case Management Connector (complaints, service requests)
  - Payments Connector (bills, taxes, fees)
  - Identity/KYC Connector (verify/gate services)
  - GIS/Location (ward/zone routing), Scheduler (appointments)
  - Document Capture (uploads), Language/Translation, Consent & Privacy
  - Guardrail Policy (approved public copy), Human Handoff, Memory Store
- **Channel Nodes**
  - WhatsApp, Web Chat, IVR/Voice, SMS, Kiosk
- **Workflow Nodes**
  - Ticket Create/Update, Email/SMS/WhatsApp Notify, Webhook/HTTP Post
  - SLA Timer/Escalation Ladder, Payment Receipt, Audit Log, Survey (CSAT)

---

## Campaign‑Ready Use Case Stories (full flow)
Each: Trigger → Agents → Node Libraries → Bot (channels) → Workflow → Sample chat → Highlight.

### A) Grievance/Service Request Filing (Municipal)
- **Trigger**: “Pothole complaint” on WhatsApp/Web
- **Agents**: Citizen Services Template Agent
- **Node Libraries**:
  - Case Management Connector, GIS/Location, Document Capture (photos)
  - SLA/Escalation
- **Bot (Channels)**: WhatsApp + Web + IVR
- **Workflow**:
  1) Capture details + photo + location → 2) Create case → 3) Assign to ward team → 4) Share SLA/track link → 5) Escalate if overdue
- **Sample chat**:
  - Citizen: “Pothole near Gate 3.”
  - Agent: “Case #C‑271 created. Fix due in 72h. Track here.”
- **Highlight**: “Faster resolution with accountability.”

### B) Utility Bills: Enquiry & Payment (Water/Power)
- **Trigger**: “Bill amount?” / “Pay now”
- **Agents**: Citizen Services Template Agent
- **Node Libraries**:
  - Payments Connector, Account Lookup, Notifications
- **Bot (Channels)**: WhatsApp + IVR + Web
- **Workflow**:
  1) Verify account → 2) Share dues → 3) Take payment → 4) Send receipt → 5) Reminder before next due
- **Sample chat**:
  - Citizen: “Pay water bill.”
  - Agent: “Link sent. Receipt will follow.”
- **Highlight**: “Short queues, happier citizens.”

### C) Certificates: Birth/Death/Residence (Civil)
- **Trigger**: “Apply for birth certificate”
- **Agents**: Citizen Services Template Agent
- **Node Libraries**:
  - Identity/KYC (verify), Document Capture, Payments (fees)
  - Case Management (application)
- **Bot (Channels)**: Web + WhatsApp
- **Workflow**:
  1) Verify identity → 2) Collect docs → 3) Pay fee → 4) Submit application → 5) Notify readiness/collection/e‑delivery
- **Sample chat**:
  - Citizen: “Apply for birth certificate.”
  - Agent: “Docs verified. Fee paid. You’ll receive it in 3–5 days.”
- **Highlight**: “Paperwork without the paper chase.”

### D) Permit/License Application (Transport/Trade)
- **Trigger**: “Apply/renew driving license” / “Trade license renewal”
- **Agents**: Citizen Services Template Agent
- **Node Libraries**:
  - Identity/KYC, Payments, Scheduler (test/inspection slots)
  - Case Management (application tracking)
- **Bot (Channels)**: Web + WhatsApp + IVR
- **Workflow**:
  1) Pre‑screen eligibility → 2) Collect docs → 3) Pay fees → 4) Book slot → 5) Notify updates
- **Sample chat**:
  - Applicant: “Renew driving license.”
  - Agent: “Slot available Fri 10 AM. Book now?”
- **Highlight**: “Clear steps. Faster completion.”

### E) Property Tax & Assessment (Revenue)
- **Trigger**: “Property tax due?”
- **Agents**: Citizen Services Template Agent
- **Node Libraries**:
  - Payments Connector, GIS/Assessment Lookup
- **Bot (Channels)**: WhatsApp + Web + IVR
- **Workflow**:
  1) Fetch dues → 2) Share breakdown → 3) Collect payment → 4) Issue receipt → 5) Reminder next cycle
- **Sample chat**:
  - Citizen: “Pay property tax now.”
- **Highlight**: “Collections, simplified.”

### F) Public Health: Info & Appointments
- **Trigger**: “Vaccination camp schedule?” / “Book slot”
- **Agents**: Citizen Services Template Agent
- **Node Libraries**:
  - Knowledge Base (advisories), Scheduler (camp slots)
  - Broadcast/Notify (ward‑wise)
- **Bot (Channels)**: WhatsApp + Web + IVR
- **Workflow**:
  1) Share info → 2) Book slot → 3) Send reminders → 4) Post‑visit survey
- **Sample chat**:
  - Citizen: “Flu shots near me?”
  - Agent: “Camp at Ward‑14 on Sat. 10:30 AM slot available. Book?”
- **Highlight**: “Right info, right time.”

### G) Transport/Ticketing & Route Info
- **Trigger**: “Next bus for Route 22?”
- **Agents**: Citizen Services Template Agent
- **Node Libraries**:
  - Transit/GTFS Connector (timetable/ETAs)
  - Payments (pass/ticket)
- **Bot (Channels)**: WhatsApp + Web + Kiosk
- **Workflow**:
  1) Share live ETA → 2) Offer pass/ticket → 3) Send QR → 4) Feedback
- **Sample chat**:
  - Citizen: “Next metro at MG Road?”
  - Agent: “ETA 4 mins. Want a QR single‑ride?”
- **Highlight**: “Smoother commutes.”

### H) Emergency/Disaster Broadcasts (Crisis)
- **Trigger**: Authority alert
- **Agents**: Citizen Services Template Agent
- **Node Libraries**:
  - Broadcast/Notify, GIS/Location (geofenced)
  - Multilingual/Translation
- **Bot (Channels)**: WhatsApp + SMS + IVR + Web
- **Workflow**:
  1) Select area → 2) Multilingual alert → 3) Safety instructions → 4) Acknowledge receipts → 5) Follow‑ups
- **Sample copy**:
  - “Heavy rainfall alert for Ward‑8. Avoid underpasses. Helpline: 1912.”
- **Highlight**: “Reach everyone, fast.”

---

## Social‑Ready Assets
- **Hooks**
  - “Serve citizens on the channels they use.”
  - “Paperwork without queues.”
  - “Updates that build trust.”
- **One‑liners**
  - “24×7 citizen services.”
  - “From complaint to closure — trackable.”
  - “Multilingual by design.”
- **Visual ideas**
  - Flow: Trigger → Agent → Nodes → Bot → Workflow → KPI
  - Grievance card: photo → case → SLA → status
  - Permit card: eligibility → docs → slot → receipt
- **CTAs**
  - “Try the Citizen Services Template Agent”
  - “See grievance to closure in 60 seconds”
  - “Talk to us about core integrations”

## Compliance Notes
- Use approved public copy; avoid sensitive data in open channels.
- Consent/opt‑in and data minimization; store audit trails.
- Support accessibility and multilingual requirements.

## KPIs to Feature
- Call/counter reduction, SLA adherence, time‑to‑resolution, CSAT, on‑time collections.

## Build in 5 Steps (recap)
1) Create Citizen Services Template Agent
2) Add Agent Nodes (Case, Payments, ID/KYC, GIS, Docs, Guardrail, Memory)
3) Create Bot (connect WhatsApp/Web/IVR/SMS)
4) Add Workflow (tickets, payments, broadcasts, escalations, audit)
5) Launch pilot; measure and iterate

## Outcomes (headline copy)
- **Citizens**: Faster answers, transparent status, fewer visits
- **Agencies**: Fewer calls, better SLA control, cleaner compliance
