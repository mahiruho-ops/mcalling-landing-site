# Healthcare Use Cases — MChatbot (Marketing-Ready)

- **Audience**: Marketing, Growth, Product Marketing, Sales Enablement, Hospital Ops
- **Goal**: Launch campaigns, ads, blogs, reels, and sales decks quickly with clear storylines
- **Template**: Healthcare Template Agent (from Template Agents)

## Quick Pitch (use in intros, posts, or video VO)
“MChatbot helps hospitals automate patient access, triage, bookings, insurance checks, and follow‑ups across Web, WhatsApp, SMS, and IVR — with enterprise guardrails and audit trails.”

## Key Outcomes to Promote
- 40–60% fewer front‑desk calls
- 15–30% no‑show reduction via smart reminders
- <30 sec first response on Web/WhatsApp
- Consistent, compliant messaging across all channels

## Building Blocks (simple language)
- **Template Agent**: The brain (tone + model + knowledge + policies)
- **Node Libraries**: Plug‑in blocks to add skills (APIs, knowledge, rules, handoff)
- **Bot**: Connects the Agent to channels (Web, WhatsApp, IVR, etc.)
- **Workflow**: What happens after chat (emails, EHR updates, reminders, tickets)

## Node Libraries (choose what you need)
- **Agent Nodes**
  - Knowledge Base Connector (FAQs, prep guides, consent)
  - API Tool (HTTP) to EHR/EMR, insurance, scheduler, payments
  - Memory Store (remember context with retention rules)
  - Guardrail Policy (no diagnosis, escalate red flags, mask PII)
  - Data Mapper (align fields between chat and hospital systems)
  - Human Handoff (live agent / staff queue)
- **Channel Nodes**
  - Web Chat, WhatsApp, SMS, IVR/Voice, Telegram
  - Internal: Slack, MS Teams
- **Workflow Nodes**
  - Email Trigger, SMS/WhatsApp Notify, Webhook/HTTP Post
  - EHR/EMR Connector (FHIR/HL7), CRM Connector
  - Scheduler (events, reminders), Payment Capture, Audit Log
  - Consent/Opt‑in, Data Export, Ticket Create

---

## Campaign‑Ready Use Case Stories (full flow)
Each example lists: Trigger → Agents → Node Libraries → Bot (channels) → Workflow → Sample chat → What to highlight.

### A) New Patient Appointment Booking (Top‑of‑Funnel)
- **Trigger**: Website “Book Now” button or WhatsApp QR code at reception
- **Agents**: Healthcare Template Agent
- **Node Libraries**:
  - Knowledge Base Connector (specialties, hours)
  - API Tool (Scheduler/EHR create‑appointment)
  - Guardrail Policy (no diagnosis)
  - Memory Store (name, DOB)
- **Bot (Channels)**: Web Chat + WhatsApp
- **Workflow**:
  1) Validate details → 2) Create appointment in EHR → 3) Send confirmation → 4) Schedule reminders (T‑24h, T‑2h) → 5) Log audit
- **Sample chat**:
  - Patient: “Need cardiology appointment.”
  - Agent: “Next slot Tue 11:30 AM with Dr. Rao. Confirm?”
  - Patient: “Yes.”
  - Agent: “Booked. You’ll get reminders.”
- **Highlight**: “From click to confirmed in under a minute.”

### B) Symptom Triage → Human Handoff (Mid‑funnel safety)
- **Trigger**: “Chest pain since morning” on Web/WhatsApp
- **Agents**: Healthcare Template Agent → Human Staff (handoff)
- **Node Libraries**:
  - Guardrail Policy (red‑flag detection)
  - Human Handoff (staff queue)
  - Knowledge Base (triage guidance, disclaimers)
- **Bot (Channels)**: Web + WhatsApp (with handoff to MS Teams channel for staff)
- **Workflow**:
  1) Detect red flag → 2) Immediate handoff → 3) Notify staff → 4) Create urgent ticket → 5) Log audit
- **Sample chat**:
  - Patient: “Sharp chest pain.”
  - Agent: “This may need urgent attention. I’m connecting you now.”
  - Staff joins chat.
- **Highlight**: “Built‑in safety. Escalates instantly.”

### C) Insurance Verification & Co‑pay Estimate (Consideration → Booking)
- **Trigger**: Patient asks “Is this covered?” on Web/WhatsApp
- **Agents**: Healthcare Template Agent
- **Node Libraries**:
  - API Tool (insurer coverage check)
  - Data Mapper (payer/memberId fields)
  - Memory Store (store coverage summary)
- **Bot (Channels)**: Web + WhatsApp
- **Workflow**:
  1) Capture payer + memberId → 2) Verify coverage → 3) Store summary → 4) Share co‑pay range → 5) Offer to book
- **Sample chat**:
  - Patient: “Is MRI covered?”
  - Agent: “Coverage confirmed. Estimated co‑pay $60–$80. Want to book?”
- **Highlight**: “Removes uncertainty. Increases conversion.”

### D) Prescription Refill (Retention)
- **Trigger**: “Refill Metformin 500mg” via WhatsApp
- **Agents**: Healthcare Template Agent → (optional) Prescriber Agent for policy checks
- **Node Libraries**:
  - API Tool (Rx history/eligibility)
  - Guardrail Policy (no off‑label, verify identity)
  - Notifications (WhatsApp/SMS)
- **Bot (Channels)**: WhatsApp
- **Workflow**:
  1) Verify patient → 2) Check refill eligibility → 3) Request physician approval → 4) Notify pickup/delivery → 5) Log audit
- **Sample chat**:
  - Patient: “Need refill.”
  - Agent: “Verified and approved. Pickup tomorrow.”
- **Highlight**: “Refills without call queues.”

### E) Lab Results → Doctor Review (Upsell to consult)
- **Trigger**: Lab marks results ready (Webhook)
- **Agents**: Healthcare Template Agent
- **Node Libraries**:
  - API Tool (lab status)
  - Notifications (secure link)
  - Scheduler (review slot)
- **Bot (Channels)**: WhatsApp + Email
- **Workflow**:
  1) Generate tokenized link → 2) Notify patient → 3) Offer review slot → 4) Create appointment → 5) Log audit
- **Sample chat**:
  - Agent: “Your report is ready. Review with a doctor?”
  - Patient: “Tomorrow 5 PM works.”
- **Highlight**: “Turns lab moments into meaningful follow‑ups.”

### F) Post‑Discharge Follow‑up & Feedback (Retention + QoQ)
- **Trigger**: Discharge event from EHR (Webhook)
- **Agents**: Healthcare Template Agent
- **Node Libraries**:
  - Knowledge Base (care plan instructions)
  - Notifications (reminders)
  - Survey Node (CSAT/NPS)
- **Bot (Channels)**: WhatsApp + SMS
- **Workflow**:
  1) Send care plan → 2) Daily reminders (meds/physio) → 3) Collect feedback → 4) Flag low scores → 5) Log audit
- **Sample chat**:
  - Agent: “How’s recovery? Need any help?”
  - Patient: “All good.”
- **Highlight**: “Closes the loop. Boosts outcomes & reviews.”

### G) Vaccination & Preventive Campaigns (Acquisition)
- **Trigger**: Seasonal outreach campaign (bulk)
- **Agents**: Healthcare Template Agent
- **Node Libraries**:
  - Broadcast/Notify Node
  - Scheduler (campaign calendar)
  - Consent/Opt‑in
- **Bot (Channels)**: WhatsApp + SMS + Email
- **Workflow**:
  1) Send outreach → 2) Collect intent → 3) Offer booking → 4) Confirm + reminders → 5) Track conversions
- **Sample chat**:
  - Agent: “Flu shots open. Book a slot?”
  - Patient: “Yes, Saturday morning.”
- **Highlight**: “Targeted outreach that converts.”

### H) Chronic Care Check‑ins (Engagement)
- **Trigger**: Recurring schedule (weekly/monthly)
- **Agents**: Healthcare Template Agent
- **Node Libraries**:
  - Scheduler (recurrence)
  - Memory Store (baseline values)
  - Human Handoff (if thresholds exceeded)
- **Bot (Channels)**: WhatsApp + Web
- **Workflow**:
  1) Ask readings (BP/Glucose) → 2) Compare to baseline → 3) If high, notify care team → 4) Offer appointment → 5) Log audit
- **Sample chat**:
  - Agent: “Today’s BP?”
  - Patient: “140/90.”
  - Agent: “Noted. Would you like a nurse to check in?”
- **Highlight**: “Proactive care. Lower ER risk.”

---

## Social‑Ready Assets (copy/paste)
- **Hooks**
  - “Booked in under a minute. Across any channel.”
  - “Fewer calls, fewer no‑shows, happier patients.”
  - “From symptom to slot — safely, with guardrails.”
- **One‑liners**
  - “Your 24×7 healthcare front desk.”
  - “Triage, booking, and follow‑ups — automated.”
  - “Enterprise guardrails. Consumer‑grade experience.”
- **Visual ideas**
  - Split screen: left (phone with WhatsApp), right (calendar fills itself)
  - Funnel graphic: Trigger → Agent → Nodes → Bot → Workflow → KPI
  - “Before vs After” card: Call queues vs. Instant confirmation
- **CTAs**
  - “Try the Healthcare Template Agent”
  - “See a live booking in 60 seconds”
  - “Talk to us about EHR integrations”

## Compliance Notes (keep your copy safe)
- Avoid medical diagnosis claims; position as triage/guidance.
- Include consent/opt‑in lines for messaging.
- Don’t promise outcomes; use ranges/estimates and “may/helps”.
- Keep PHI minimal in examples/screenshots.

## KPIs to Feature in Creatives
- Booking conversion, no‑show reduction, first response time, CSAT/NPS, staff hours saved/week.

## Build in 5 Steps (recap)
1) Create Healthcare Template Agent
2) Add Agent Nodes (Knowledge, API Tool, Guardrail, Memory)
3) Create Bot (connect channels)
4) Add Workflow (notify, scheduler, EHR post, audit)
5) Launch pilot, measure, iterate

## Outcomes (headline copy)
- **Patients**: Fast bookings, clear reminders, quick lab updates, simple refills
- **Staff**: Fewer calls, fewer no‑shows, faster verification, clean audit trail


