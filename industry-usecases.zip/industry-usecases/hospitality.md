# Hospitality Use Cases — MChatbot (Marketing-Ready)

- **Audience**: Hotel/Resort GMs, Revenue, Sales, Front Office, Guest Experience, Marketing
- **Goal**: Drive direct bookings, upsell ancillaries, reduce front-desk load, boost reviews
- **Template**: Hospitality Template Agent (from Template Agents)

## Quick Pitch
“Automate bookings, check-ins, concierge, upsells, and post-stay reviews across Web, WhatsApp, SMS, and IVR — with brand voice and enterprise controls.”

## Key Outcomes to Promote
- +10–25% uplift in direct bookings
- +8–20% ancillary revenue (upsells: rooms, spa, dining)
- <30 sec first response; fewer front-desk calls
- More 5★ reviews via proactive follow-ups

## Building Blocks (simple)
- **Template Agent**: The brain (tone + model + hotel knowledge + policies)
- **Node Libraries**: Plug-in blocks for skills (PMS, booking engine, POS, loyalty, payments)
- **Bot**: Connects the Agent to channels (Web, WhatsApp, IVR, etc.)
- **Workflow**: After-chat automations (emails, PMS updates, tickets, reminders)

## Node Libraries (pick what you need)
- **Agent Nodes**
  - Knowledge Base Connector (amenities, policies, FAQs, brand style)
  - PMS/Booking Engine API Tool (rates, availability, reservations)
  - POS/Restaurant API Tool (table booking, menus)
  - Loyalty/CRM Connector (member lookup, offers)
  - Upsell Recommender (room upgrades, spa, dining, late checkout)
  - Memory Store (guest preferences; retention rules)
  - Guardrail Policy (policy compliance; escalation)
  - Human Handoff (concierge/live agent)
- **Channel Nodes**
  - Web Chat, WhatsApp, SMS, IVR/Voice, Instagram/FB Messenger
  - Internal: Slack/MS Teams (ops/concierge back-office)
- **Workflow Nodes**
  - Email Trigger, SMS/WhatsApp Notify, Webhook/HTTP Post
  - PMS/Booking Engine Connector, POS Connector
  - Payment Capture, Invoice/Receipt, Scheduler (reminders)
  - Ticket Create (housekeeping/maintenance), Survey (CSAT/NPS), Audit Log

---

## Campaign-Ready Use Case Stories (full flow)
Each example: Trigger → Agents → Node Libraries → Bot (channels) → Workflow → Sample chat → Highlight.

### A) Direct Room Booking (Revenue Engine)
- **Trigger**: Website “Book Now” or WhatsApp QR at reception
- **Agents**: Hospitality Template Agent
- **Node Libraries**:
  - PMS/Booking Engine API Tool (rates/availability, reservation create)
  - Knowledge Base Connector (rooms, policies)
  - Payment Capture (deposit/guarantee)
  - Upsell Recommender (upgrade options)
- **Bot (Channels)**: Web Chat + WhatsApp
- **Workflow**:
  1) Collect dates/guests → 2) Fetch rates → 3) Reserve room → 4) Offer upgrade → 5) Payment/guarantee → 6) Confirmation → 7) Reminders
- **Sample chat**:
  - Guest: “Room for 2, 13–15 May.”
  - Agent: “Deluxe ₹6,800/night; Suite ₹9,900/night. Upgrade to Suite with lounge access?”
  - Guest: “Suite. Book.”
  - Agent: “Booked. Confirmation sent. See you soon!”
- **Highlight**: “From browse to booked — with a profitable upsell.”

### B) Pre-Arrival Check-in & Upgrade (CS + Ancillary)
- **Trigger**: T-48h automated outreach
- **Agents**: Hospitality Template Agent
- **Node Libraries**:
  - PMS API Tool (reservation lookup/check-in)
  - Upsell Recommender (late checkout, airport pickup, spa)
  - Payment Capture (add-ons)
- **Bot (Channels)**: WhatsApp + Email
- **Workflow**:
  1) Verify booking → 2) Offer online check-in → 3) Upsell add-ons → 4) Confirm → 5) Notify front desk → 6) Audit log
- **Sample chat**:
  - Agent: “Online check-in available. Add airport pickup at ₹1200?”
  - Guest: “Yes. Also late checkout.”
  - Agent: “Done. See you tomorrow!”
- **Highlight**: “Faster arrivals, higher pre-arrival revenue.”

### C) Concierge & Local Recommendations (Experience)
- **Trigger**: “What’s good for dinner nearby?”
- **Agents**: Hospitality Template Agent
- **Node Libraries**:
  - Knowledge Base (onsite dining hours, menus)
  - POS/Restaurant API Tool (table booking)
  - Human Handoff (concierge)
- **Bot (Channels)**: Web + WhatsApp
- **Workflow**:
  1) Suggest venues → 2) Book table → 3) Confirm & remind → 4) Log guest preference
- **Sample chat**:
  - Guest: “Dinner for 2 at 8?”
  - Agent: “Italian or Indian? Italian table at Trattoria confirmed for 8 PM.”
- **Highlight**: “Concierge in the guest’s pocket.”

### D) Housekeeping/Maintenance Requests (Ops)
- **Trigger**: “Need extra towels” or “AC not cooling”
- **Agents**: Hospitality Template Agent
- **Node Libraries**:
  - Ticket Create (housekeeping/engineering)
  - Scheduler (ETA/reminders)
  - Human Handoff (if urgent)
- **Bot (Channels)**: WhatsApp + Web
- **Workflow**:
  1) Classify request → 2) Create ticket → 3) Notify team → 4) Update guest with ETA → 5) Close + feedback
- **Sample chat**:
  - Guest: “Extra towels please.”
  - Agent: “On the way in 10 minutes.”
- **Highlight**: “Fixes fast. Happy guests, efficient teams.”

### E) Event & Group Inquiries (MICE)
- **Trigger**: Website “Plan an Event”
- **Agents**: Hospitality Template Agent → Sales Agent (handoff)
- **Node Libraries**:
  - CRM Connector (lead capture)
  - Knowledge Base (banquet capacities, AV, packages)
  - Human Handoff (sales)
- **Bot (Channels)**: Web Chat
- **Workflow**:
  1) Qualify (date, pax, budget) → 2) Create CRM lead → 3) Schedule site visit → 4) Sales handoff → 5) Audit
- **Sample chat**:
  - Planner: “Conference for 80, next month.”
  - Agent: “Ballroom fits 120. Site visit tomorrow 4 PM?”
- **Highlight**: “Captures MICE leads instantly.”

### F) Post-Stay Review & Win-Back (Reputation)
- **Trigger**: Check-out Webhook
- **Agents**: Hospitality Template Agent
- **Node Libraries**:
  - Survey Node (CSAT/NPS)
  - Broadcast/Notify (review links)
  - Loyalty/CRM Connector (offer code)
- **Bot (Channels)**: WhatsApp + Email
- **Workflow**:
  1) Collect feedback → 2) If high score, request public review → 3) If low, alert manager → 4) Send win-back offer
- **Sample chat**:
  - Agent: “How was your stay?”
  - Guest: “Great!”
  - Agent: “Thank you! Would you share a quick review?”
- **Highlight**: “More 5★ reviews, automated.”

---

## Social-Ready Assets
- **Hooks**
  - “Upgrade revenue that sells itself.”
  - “Check-in before you arrive.”
  - “Concierge replies in seconds — on any channel.”
- **One-liners**
  - “Your guest experience, on autopilot.”
  - “From browse to booked — with upsells.”
  - “Less queue. More wow.”
- **Visual ideas**
  - Upsell carousel: room upgrade → spa → dining → late checkout
  - Flow graphic: Trigger → Agent → Nodes → Bot → Workflow → KPI
  - Chat mock: ‘Suite + lounge?’ → ‘Yes’ → revenue bar climbs
- **CTAs**
  - “Try the Hospitality Template Agent”
  - “See a 60-second booking demo”
  - “Talk to us about PMS integrations”

## Compliance Notes
- Don’t promise room types until confirmed by PMS.
- Keep payment flows secure; avoid storing card data outside the gateway.
- Respect opt-in/opt-out; follow brand tone guidelines.

## KPIs to Feature
- Direct booking conversion, ancillary revenue per stay, first response time, CSAT/NPS, ticket resolution time.

## Build in 5 Steps (recap)
1) Create Hospitality Template Agent
2) Add Agent Nodes (Knowledge, PMS/Booking API, Upsell, Guardrail, Memory)
3) Create Bot (connect Web/WhatsApp/IVR)
4) Add Workflow (notify, PMS/CRM post, payment, tickets, survey)
5) Launch pilot; measure and iterate

## Outcomes (headline copy)
- **Guests**: Faster bookings, instant concierge, smooth arrivals, useful recommendations
- **Teams**: Fewer calls, upsell at scale, faster ops tickets, more 5★ reviews
