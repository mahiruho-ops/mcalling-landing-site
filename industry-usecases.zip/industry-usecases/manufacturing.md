# Manufacturing Use Cases — MChatbot (Marketing-Ready)

- **Audience**: Plant/Factory Ops, Supply Chain, Procurement, Quality, Maintenance, Logistics, IT/OT
- **Goal**: Reduce downtime, accelerate RFQs/orders, improve quality loops, streamline logistics, deflect FAQs
- **Template**: Manufacturing Template Agent (from Template Agents)

## Quick Pitch
“Digitize shop‑floor and supply‑chain conversations — RFQs, parts lookup, downtime alerts, quality incidents, and shipment tracking — across Teams/WhatsApp/Web, connected to ERP/MES.”

## Key Outcomes to Promote
- Faster RFQ→PO cycle time (hours → minutes)
- Lower downtime via faster triage (MTTA/MTTR)
- Fewer line interruptions (self‑serve parts/info)
- On‑time in‑full (OTIF) improvement via proactive tracking

## Building Blocks (simple)
- **Template Agent**: The brain (tone + model + SOPs/parts/quality manuals + policies)
- **Node Libraries**: Plug‑in blocks (ERP/MES/PLM/QMS/CMMS/WMS, IoT/SCADA, Carriers, EDI)
- **Bot**: Connects the Agent to channels (MS Teams/Slack, WhatsApp, Web, IVR)
- **Workflow**: After‑chat automations (tickets, ERP/MES updates, broadcasts, audits)

## Node Libraries (pick what you need)
- **Agent Nodes**
  - Knowledge Base Connector (SOPs, part catalogs, work instructions)
  - ERP/MES Connector (SAP/Oracle/Custom), PLM/QMS Connector
  - CMMS Connector (work orders), WMS Connector (inventory/transfer)
  - Logistics/Carrier Connector (track/ETA), EDI Connector (ASN/PO/INV)
  - IoT/SCADA Alert Ingest, Recommender (spares, alternates)
  - Guardrail Policy (safety wording, compliance), Human Handoff, Memory Store
- **Channel Nodes**
  - MS Teams/Slack (internal), WhatsApp, Web Chat, IVR/Voice
- **Workflow Nodes**
  - Ticket Create (Jira/ServiceNow), Email/SMS/WhatsApp Notify, Webhook/HTTP Post
  - ERP/MES Update, CMMS WO Create, WMS Transfer, Audit Log, Survey (CSAT)

---

## Campaign‑Ready Use Case Stories (full flow)
Each: Trigger → Agents → Node Libraries → Bot (channels) → Workflow → Sample chat → Highlight.

### A) RFQ Intake & Quote Back (Procurement)
- **Trigger**: Supplier clicks “Submit RFQ” widget or WhatsApp link
- **Agents**: Manufacturing Template Agent
- **Node Libraries**:
  - ERP Connector (item master, RFQ create)
  - Document Capture (specs/drawings)
  - Email/WhatsApp Notify
- **Bot (Channels)**: Web + WhatsApp
- **Workflow**:
  1) Capture item/specs → 2) Create RFQ → 3) Notify buyer → 4) Share status with supplier
- **Sample chat**:
  - Supplier: “RFQ for PN‑8821, qty 1,000.”
  - Agent: “RFQ‑#3491 created. Buyer will revert within 24h.”
- **Highlight**: “Clean intake. Fewer emails. Faster quotes.”

### B) Spare Parts Lookup & Pick (Maintenance/Stores)
- **Trigger**: Technician scans QR at machine or messages WhatsApp
- **Agents**: Manufacturing Template Agent
- **Node Libraries**:
  - WMS Connector (stock/locations), Recommender (alternates)
  - CMMS Connector (attach to WO)
- **Bot (Channels)**: WhatsApp + MS Teams
- **Workflow**:
  1) Identify machine/part → 2) Check stock/location → 3) Suggest alternates → 4) Reserve or trigger pick → 5) Attach to WO
- **Sample chat**:
  - Tech: “Seal kit for Press‑04.”
  - Agent: “Aisle B‑14, 6 in stock. Reserve 1?”
- **Highlight**: “Parts in minutes, not hours.”

### C) Machine Downtime Alert Triage (Ops)
- **Trigger**: IoT/SCADA alert or Teams message “Press‑04 down”
- **Agents**: Manufacturing Template Agent → Maintenance Agent (optional)
- **Node Libraries**:
  - IoT/SCADA Alert Ingest, CMMS Connector (WO), SOP KB
  - Human Handoff (supervisor)
- **Bot (Channels)**: MS Teams
- **Workflow**:
  1) Summarize alert → 2) Suggest first‑steps SOP → 3) Create WO → 4) Notify team → 5) Track MTTR
- **Sample chat**:
  - Bot: “Hydraulic pressure low. Check valve V‑12 per SOP‑H34?”
- **Highlight**: “Lower MTTR with instant runbooks.”

### D) Quality NCR/CAPA Intake (QA)
- **Trigger**: Operator submits defect photo in Teams/Web
- **Agents**: Manufacturing Template Agent
- **Node Libraries**:
  - QMS Connector (NCR create/CAPA link), Document Capture
  - Email Notify (QA lead)
- **Bot (Channels)**: Teams + Web
- **Workflow**:
  1) Capture defect details/photos → 2) Create NCR → 3) Link CAPA → 4) Notify QA
- **Sample chat**:
  - Operator: “Scratch on finish, lot L‑227.”
  - Agent: “NCR‑#1042 created. CAPA draft ready.”
- **Highlight**: “Audit‑ready quality trails.”

### E) Production Schedule & Change Notice (Planning)
- **Trigger**: Planner posts change or worker asks “Today’s schedule?”
- **Agents**: Manufacturing Template Agent
- **Node Libraries**:
  - MES/ERP Connector (work orders/schedule), Broadcast
- **Bot (Channels)**: MS Teams + Web
- **Workflow**:
  1) Fetch schedule → 2) Broadcast change → 3) Confirm acks → 4) Log
- **Sample chat**:
  - Agent: “Line‑2 shifts to PN‑2210 for 2nd half.”
- **Highlight**: “Fewer floor surprises.”

### F) Shipment Tracking & ASN (Logistics)
- **Trigger**: “Track PO‑7755” on WhatsApp/Web
- **Agents**: Manufacturing Template Agent
- **Node Libraries**:
  - Carrier Connector (AWB/ETA), EDI Connector (ASN)
  - Notifications (exceptions)
- **Bot (Channels)**: WhatsApp + Web
- **Workflow**:
  1) Fetch status → 2) Show ETA → 3) Notify delays → 4) Share ASN details
- **Sample chat**:
  - Planner: “ETA for PO‑7755?”
  - Agent: “Arrives tomorrow by 2 PM. ASN #A45 posted.”
- **Highlight**: “Proactive tracking. Fewer calls.”

### G) Inter‑plant Inventory Check & Transfer (Supply Chain)
- **Trigger**: “Need PN‑552 at Plant‑B”
- **Agents**: Manufacturing Template Agent
- **Node Libraries**:
  - WMS Connector (stock), ERP Transfer Order
- **Bot (Channels)**: MS Teams + Web
- **Workflow**:
  1) Check Plant‑A/B stock → 2) Create transfer order → 3) Notify stores → 4) Log
- **Sample chat**:
  - Agent: “Transfer order TO‑983 created for 120 units.”
- **Highlight**: “Balances stock quickly.”

### H) Safety/EHS Incident Reporting (Compliance)
- **Trigger**: WhatsApp/Teams “Near miss” with photo
- **Agents**: Manufacturing Template Agent
- **Node Libraries**:
  - EHS Form/Document Capture, Ticket Create, Broadcast (safety alert)
- **Bot (Channels)**: WhatsApp + Teams
- **Workflow**:
  1) Capture details → 2) Create ticket → 3) Alert safety group → 4) Track closure → 5) Log
- **Sample chat**:
  - Worker: “Oil spill near Line‑3.”
  - Agent: “Ticket #SAFE‑117 opened. Team alerted.”
- **Highlight**: “Safer floors, faster action.”

---

## Social‑Ready Assets
- **Hooks**
  - “From RFQ to PO — without email chaos.”
  - “Downtime triage in chat, MTTR down.”
  - “Quality incidents that are audit‑ready.”
- **One‑liners**
  - “Shop‑floor ops, digitized.”
  - “Inventory, tickets, and ETAs — on demand.”
  - “Connected to ERP/MES. Loved by Teams.”
- **Visual ideas**
  - Flow: Trigger → Agent → Nodes → Bot → Workflow → KPI
  - Shop‑floor QR → chat → part location card
  - Teams incident card: alert → SOP → WO
- **CTAs**
  - “Try the Manufacturing Template Agent”
  - “See RFQ and downtime triage in 60 seconds”
  - “Talk to us about ERP/MES integrations”

## Compliance Notes
- Safety copy must follow site policy; avoid prescriptive medical advice.
- Respect supplier/employee data privacy; mask sensitive fields.
- Keep change/audit logs enabled for reviews.

## KPIs to Feature
- RFQ→PO time, MTTA/MTTR, OTIF, stock‑out reduction, ticket resolution time, CSAT.

## Build in 5 Steps (recap)
1) Create Manufacturing Template Agent
2) Add Agent Nodes (ERP/MES, WMS/CMMS, Logistics, Guardrail, Memory)
3) Create Bot (connect Teams/Slack/WhatsApp/Web)
4) Add Workflow (tickets, ERP/WMS updates, broadcasts, audit)
5) Launch pilot; measure and iterate

## Outcomes (headline copy)
- **Teams**: Faster RFQs, quicker fixes, clearer schedules, fewer calls
- **Business**: Less downtime, better OTIF, improved compliance, happier partners
