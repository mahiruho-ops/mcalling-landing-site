# Retail Use Cases — MChatbot (Marketing-Ready)

- **Audience**: Ecommerce Leaders, Omnichannel, Growth/CRM, CX, Store Ops, Marketing
- **Goal**: Increase conversions, reduce support load, grow AOV/LTV, smooth returns and pickups
- **Template**: Retail Template Agent (from Template Agents)

## Quick Pitch
“Guide shoppers from discovery to purchase, support orders and returns, and drive repeat sales across Web, WhatsApp, SMS, and in‑store — with enterprise guardrails.”

## Key Outcomes to Promote
- +8–20% conversion uplift with guided selling
- +5–15% AOV uplift via smart recommendations
- <30 sec first response; fewer support tickets
- Faster returns/RMA and BOPIS (click‑and‑collect)

## Building Blocks (simple)
- **Template Agent**: The brain (tone + model + product/brand knowledge + policies)
- **Node Libraries**: Plug‑in blocks for skills (commerce, inventory, payments, logistics, CRM/CDP)
- **Bot**: Connects the Agent to channels (Web, WhatsApp, SMS, kiosk)
- **Workflow**: After‑chat automations (emails, order update, RMA, tickets, reminders)

## Node Libraries (pick what you need)
- **Agent Nodes**
  - Knowledge Base Connector (catalog guides, size charts, policies)
  - Commerce Platform Connector (Shopify/Magento/Custom)
  - Inventory/PIM Connector (stock, variants, attributes)
  - Recommender (related items, bundles, upsells)
  - Promotions/Pricing (apply codes, explain offers)
  - Payment Capture (checkout link, partial pay)
  - Memory Store (preferences; retention rules)
  - Guardrail Policy (returns policy compliance; escalation)
  - Human Handoff (support/sales)
- **Channel Nodes**
  - Web Chat, WhatsApp, SMS, Instagram/FB Messenger, Kiosk/Tablet
  - Internal: Slack/MS Teams for agent handoffs
- **Workflow Nodes**
  - Email Trigger, SMS/WhatsApp Notify, Webhook/HTTP Post
  - Order Management Connector, RMA/Returns Connector
  - Shipment/Carrier Connector (tracking), Store Locator/Appointment
  - Ticket Create (helpdesk), Survey (CSAT/NPS), Audit Log

---

## Campaign‑Ready Use Case Stories (full flow)
Each example: Trigger → Agents → Node Libraries → Bot (channels) → Workflow → Sample chat → Highlight.

### A) Product Discovery & Guided Selling (Top‑funnel → Conversion)
- **Trigger**: Website “Ask for advice” or WhatsApp QR in ads
- **Agents**: Retail Template Agent
- **Node Libraries**:
  - Knowledge Base Connector (size guide, use cases)
  - Recommender (top sellers, bundles)
  - Commerce Connector (add to cart, create checkout)
  - Promotions/Pricing (apply code)
- **Bot (Channels)**: Web Chat + WhatsApp
- **Workflow**:
  1) Ask use‑case/budget → 2) Recommend products → 3) Add to cart → 4) Apply promo → 5) Create checkout link → 6) Reminder if abandoned
- **Sample chat**:
  - Shopper: “Running shoes for flat feet under ₹5,000.”
  - Agent: “These 2 fit your need. Add size 9?”
  - Shopper: “Yes.”
  - Agent: “Added. 10% off today — here’s your checkout link.”
- **Highlight**: “Answers + cart in one chat. Less drop‑off.”

### B) Order Tracking & Proactive Updates (Post‑purchase)
- **Trigger**: Shopper enters order ID on WhatsApp/Web
- **Agents**: Retail Template Agent
- **Node Libraries**:
  - Order Management Connector (order status)
  - Shipment/Carrier Connector (AWB, ETA)
  - Notifications (WhatsApp/SMS)
- **Bot (Channels)**: WhatsApp + Web
- **Workflow**:
  1) Verify order → 2) Show live status/ETA → 3) Notify exceptions → 4) Offer support → 5) Log audit
- **Sample chat**:
  - Shopper: “Track #A1276.”
  - Agent: “Out for delivery. ETA today 6–8 PM.”
- **Highlight**: “Fewer ‘where is my order?’ tickets.”

### C) Returns/RMA & Exchanges (Care + Retention)
- **Trigger**: “Return my jacket” on Web/WhatsApp
- **Agents**: Retail Template Agent
- **Node Libraries**:
  - RMA/Returns Connector (create/approve)
  - Recommender (exchange suggestions)
  - Promotions (credit/retention offer)
- **Bot (Channels)**: Web Chat + WhatsApp
- **Workflow**:
  1) Validate order/item → 2) Check policy → 3) Offer exchange/credit → 4) Create RMA + pickup label → 5) Notify status
- **Sample chat**:
  - Shopper: “Size too big.”
  - Agent: “Want to exchange for M? Free pickup arranged. Credit available if you prefer.”
- **Highlight**: “Frustration‑free returns that save the sale.”

### D) Cart Recovery & Offer Nurture (Revenue Rescue)
- **Trigger**: Abandoned cart webhook
- **Agents**: Retail Template Agent
- **Node Libraries**:
  - Commerce Connector (cart items)
  - Promotions (targeted code)
  - Recommender (complements)
- **Bot (Channels)**: WhatsApp + Email
- **Workflow**:
  1) Send reminder → 2) Offer incentive → 3) Rebuild cart → 4) Share checkout → 5) Track conversions
- **Sample chat**:
  - Agent: “Still eyeing the trail shoes? Extra 5% off ends today. Want me to rebuild your cart?”
  - Shopper: “Yes.”
- **Highlight**: “Gentle nudge. Real revenue.”

### E) Store Locator & Appointment (Omnichannel)
- **Trigger**: “Nearest store with size 9”
- **Agents**: Retail Template Agent
- **Node Libraries**:
  - Inventory/Store Locator
  - Appointment/Scheduler
- **Bot (Channels)**: Web + WhatsApp + Kiosk
- **Workflow**:
  1) Find nearby stock → 2) Hold item → 3) Book try‑on slot → 4) Send directions → 5) Remind
- **Sample chat**:
  - Shopper: “Size 9 in Andheri?”
  - Agent: “Available at Infinity Mall. Hold and book 6 PM?”
- **Highlight**: “Clicks that become footfalls.”

### F) BOPIS/Click‑and‑Collect (Speed to possession)
- **Trigger**: Order placed with store pickup
- **Agents**: Retail Template Agent
- **Node Libraries**:
  - Order Management Connector (pickup status)
  - Notifications (ready for pickup)
  - Survey (pickup experience)
- **Bot (Channels)**: WhatsApp + SMS
- **Workflow**:
  1) Confirm order → 2) Notify when ready → 3) Share pickup code → 4) Collect feedback
- **Sample chat**:
  - Agent: “Order ready. Pickup code 4721.”
- **Highlight**: “Faster handover. Happy customers.”

### G) Loyalty & Personalized Offers (Retention)
- **Trigger**: Member login or campaign
- **Agents**: Retail Template Agent
- **Node Libraries**:
  - Loyalty/CRM Connector (tier, points, segments)
  - Promotions (member‑only offers)
  - Recommender (personalized picks)
- **Bot (Channels)**: Web + WhatsApp + Email
- **Workflow**:
  1) Identify member → 2) Show perks → 3) Curate picks → 4) Apply offer → 5) Share checkout
- **Sample chat**:
  - Agent: “Gold tier: 15% off on new arrivals. Want curated looks?”
- **Highlight**: “Make loyalty feel personal.”

### H) Customer Support Triage (Efficiency)
- **Trigger**: “Change address” / “Cancel order” / “Warranty”
- **Agents**: Retail Template Agent → Human Agent (handoff if complex)
- **Node Libraries**:
  - Order Management Connector (modify/cancel)
  - Ticket Create (helpdesk)
  - Human Handoff (support)
- **Bot (Channels)**: Web + WhatsApp + SMS
- **Workflow**:
  1) Classify intent → 2) Resolve simple tasks → 3) Create ticket → 4) Handoff complex cases
- **Sample chat**:
  - Shopper: “Wrong address.”
  - Agent: “Updated before dispatch. Anything else I can help with?”
- **Highlight**: “Self‑serve first. Smooth handoffs.”

---

## Social‑Ready Assets
- **Hooks**
  - “Shop with a real assistant — in chat.”
  - “From advice to checkout in one flow.”
  - “Returns made easy. Exchanges that save the sale.”
- **One‑liners**
  - “Guided shopping that converts.”
  - “Support, returns, and pickups — automated.”
  - “Omnichannel made real.”
- **Visual ideas**
  - Chat to cart: recommendation → promo → checkout link
  - Omnichannel map: Web/WhatsApp/SMS ↔ Agent ↔ Nodes ↔ Workflow
  - Before/After: email-only vs. chat-driven recovery
- **CTAs**
  - “Try the Retail Template Agent”
  - “See guided selling in 60 seconds”
  - “Talk to us about Shopify/Magento integrations”

## Compliance Notes
- Transparent pricing and promo terms; avoid overpromising stock/ETAs.
- Respect opt‑in/opt‑out on each channel.
- Don’t store card data; use payment gateway flows.

## KPIs to Feature
- Conversion rate, AOV, cart recovery rate, first response time, CSAT/NPS, return-to-exchange save rate.

## Build in 5 Steps (recap)
1) Create Retail Template Agent
2) Add Agent Nodes (Knowledge, Commerce/Inventory, Recommender, Promotions, Guardrail, Memory)
3) Create Bot (connect Web/WhatsApp/SMS)
4) Add Workflow (order updates, RMA, notifications, tickets, survey)
5) Launch pilot; measure and iterate

## Outcomes (headline copy)
- **Shoppers**: Helpful guidance, quick support, easy returns, fast pickup
- **Teams**: Fewer tickets, higher conversions, smoother operations, better loyalty
