# Technology Use Cases — MChatbot (Marketing-Ready)

- **Audience**: SaaS Founders, Product/Growth, CX/Support, Sales, DevOps/SRE, Security
- **Goal**: Increase qualified pipeline, accelerate onboarding, deflect tickets, speed incidents, drive expansion/renewals
- **Template**: Technology Template Agent (from Template Agents)

## Quick Pitch
“Guide prospects to the right plan, onboard users in‑app, resolve support instantly, and manage incidents across Slack/Teams — with enterprise guardrails and audit trails.”

## Key Outcomes to Promote
- +10–25% website‑to‑trial conversion (guided journeys)
- 20–40% support deflection (self‑serve triage)
- Faster MTTA/MTTR for incidents (Slack/Teams workflows)
- Higher NRR via timely renewals and expansions

## Building Blocks (simple)
- **Template Agent**: The brain (tone + model + docs/KB + policies)
- **Node Libraries**: Plug‑in blocks (Docs, CRM, Billing, Ticketing, Status, DevOps, SSO)
- **Bot**: Connects the Agent to channels (Web Chat, Slack/Teams, WhatsApp, Email)
- **Workflow**: After‑chat automations (tickets, emails, webhooks, escalations)

## Node Libraries (pick what you need)
- **Agent Nodes**
  - Knowledge Base Connector (docs, API refs, playbooks, pricing)
  - CRM Connector (lead create/qualify; Salesforce/HubSpot)
  - Billing Connector (Stripe/Chargebee)
  - Ticketing Connector (Zendesk/Freshdesk/Jira Service Mgmt.)
  - DevOps Connector (PagerDuty/Opsgenie), Status Connector (Statuspage)
  - Repo/Issue Connector (GitHub/Jira), Release Notes
  - SSO/Identity Verify, Guardrail Policy, Memory Store, Human Handoff
- **Channel Nodes**
  - Web Chat (site & in‑app), Slack, MS Teams, WhatsApp, Email
- **Workflow Nodes**
  - Email Trigger, Webhook/HTTP Post, Ticket Create/Update
  - Incident Broadcast, Escalation Ladder, Audit Log, Survey (CSAT/NPS)

---

## Campaign‑Ready Use Case Stories (full flow)
Each example: Trigger → Agents → Node Libraries → Bot (channels) → Workflow → Sample chat → Highlight.

### A) Product Discovery & Plan Fit (Top‑funnel → Trial)
- **Trigger**: “Find the right plan” on website
- **Agents**: Technology Template Agent
- **Node Libraries**:
  - Knowledge Base Connector (pricing/features)
  - CRM Connector (lead + qualification fields)
  - Email Trigger (trial welcome)
- **Bot (Channels)**: Web Chat
- **Workflow**:
  1) Qualify use case → 2) Recommend plan → 3) Create lead in CRM → 4) Send trial link → 5) Nurture email
- **Sample chat**:
  - Prospect: “We’re a 15‑person startup needing SSO.”
  - Agent: “Pro plan fits. Start a 14‑day trial?”
  - Prospect: “Yes.”
  - Agent: “Trial link sent. Book a 20‑min onboarding?”
- **Highlight**: “Sales‑assist that converts on first visit.”

### B) In‑App Onboarding & Product Tours (Activation)
- **Trigger**: New user opens app
- **Agents**: Technology Template Agent
- **Node Libraries**:
  - Knowledge Base Connector (guided steps)
  - Webhook (set default settings)
  - Survey (quick feedback)
- **Bot (Channels)**: In‑app Web Chat
- **Workflow**:
  1) Detect first‑run → 2) Guide setup → 3) Auto‑apply defaults → 4) Log feedback → 5) Offer help doc
- **Sample chat**:
  - User: “How do I invite my team?”
  - Agent: “Go to Settings → Team. Want me to send invites now?”
- **Highlight**: “Time‑to‑value in minutes.”

### C) Support Triage & Deflection (Care)
- **Trigger**: “Can’t connect to API” in Web/Slack
- **Agents**: Technology Template Agent → Human Agent (if needed)
- **Node Libraries**:
  - Knowledge Base (API errors), Ticketing Connector
  - Guardrail Policy, Human Handoff
- **Bot (Channels)**: Web + Slack
- **Workflow**:
  1) Classify → 2) Suggest fix → 3) If unresolved, create ticket → 4) Attach logs → 5) Notify updates
- **Sample chat**:
  - User: “401 errors on auth.”
  - Agent: “Token scope issue. Try regenerating with ‘read:orders’. Create a ticket?”
- **Highlight**: “Answers first, tickets only when needed.”

### D) Incident Triage & Escalation (Internal)
- **Trigger**: PagerDuty alert or “Service slow” in Slack
- **Agents**: Technology Template Agent → SRE Agent (optional)
- **Node Libraries**:
  - DevOps Connector (PagerDuty/Opsgenie)
  - Status Connector (Statuspage)
  - Repo/Issue Connector (Jira/GitHub)
- **Bot (Channels)**: Slack/MS Teams
- **Workflow**:
  1) Summarize alert → 2) Suggest runbook → 3) Create incident ticket → 4) Post Status → 5) Debrief survey
- **Sample chat**:
  - Bot: “High latency in US‑East. Apply autoscaling runbook?”
  - On‑call: “Run it. Open Jira ticket.”
- **Highlight**: “Lower MTTR with chat‑native automation.”

### E) Status Update & Incident Broadcast (Trust)
- **Trigger**: Planned maintenance or outage
- **Agents**: Technology Template Agent
- **Node Libraries**:
  - Status Connector, Broadcast/Notify
  - CRM Segment (affected customers)
- **Bot (Channels)**: Email + WhatsApp + Statuspage
- **Workflow**:
  1) Identify impacted accounts → 2) Send update → 3) Post on statuspage → 4) Follow‑up closure
- **Sample copy**:
  - “We’re performing maintenance 22:00–23:00 UTC. Service may be unavailable. We’ll notify when complete.”
- **Highlight**: “Proactive comms reduce ticket spikes.”

### F) Billing, Usage & Upgrades (Revenue)
- **Trigger**: “Upgrade to Pro” or “Show my usage”
- **Agents**: Technology Template Agent
- **Node Libraries**:
  - Billing Connector (plan/usage/invoice)
  - Promotions (upgrade incentives)
- **Bot (Channels)**: Web + Email
- **Workflow**:
  1) Fetch plan/usage → 2) Recommend upgrade → 3) Apply promo → 4) Send checkout link → 5) Confirm
- **Sample chat**:
  - User: “We hit limits. Options?”
  - Agent: “Pro adds SSO & higher limits. 10% off this week. Proceed?”
- **Highlight**: “Expansion in chat.”

### G) Renewal Nudge & Save (NRR)
- **Trigger**: T‑30 days to renewal
- **Agents**: Technology Template Agent
- **Node Libraries**:
  - CRM Connector (renewal date, health)
  - Broadcast/Notify, Survey (risk reason)
- **Bot (Channels)**: Email + WhatsApp
- **Workflow**:
  1) Share value recap → 2) Confirm renewal contact → 3) Surface blockers → 4) Escalate to CSM if risk
- **Sample chat**:
  - Agent: “Renewal in 30 days — extend for 12% discount?”
- **Highlight**: “Protects NRR with timely outreach.”

### H) Security & Compliance Q&A (Trust at scale)
- **Trigger**: “Do you have SOC2?”
- **Agents**: Technology Template Agent
- **Node Libraries**:
  - Knowledge Base (security whitepaper, DPA)
  - CRM Connector (log interest)
- **Bot (Channels)**: Web + Email
- **Workflow**:
  1) Answer with citations → 2) Gate docs if needed → 3) Notify sales
- **Sample chat**:
  - Prospect: “HIPAA support?”
  - Agent: “We’re not a HIPAA BA. We do offer encryption-at-rest/in-transit, SSO, SCIM.”
- **Highlight**: “Consistent, approved responses.”

---

## Social‑Ready Assets
- **Hooks**
  - “From docs to done — in chat.”
  - “Support deflection without frustration.”
  - “Incidents resolved faster, right inside Slack.”
- **One‑liners**
  - “Sales‑assist that never sleeps.”
  - “Onboarding guidance that sticks.”
  - “Trust at scale, with compliant answers.”
- **Visual ideas**
  - Flow: Trigger → Agent → Nodes → Bot → Workflow → KPI
  - Split: ‘Docs wall’ vs. ‘Chat answers’
  - Slack incident cards: alert → runbook → status → ticket
- **CTAs**
  - “Try the Technology Template Agent”
  - “See a 60‑second onboarding demo”
  - “Talk to us about Slack/Teams integrations”

## Compliance Notes
- Use approved copy for security claims; avoid overpromising.
- Keep PII minimal in chat; mask sensitive fields.
- Respect opt‑in/opt‑out for each channel.

## KPIs to Feature
- Website‑to‑trial conversion, support deflection %, MTTA/MTTR, expansion/NRR, CSAT/NPS.

## Build in 5 Steps (recap)
1) Create Technology Template Agent
2) Add Agent Nodes (KB, CRM, Billing, Ticketing, DevOps/Status, Guardrail, Memory)
3) Create Bot (connect Web/Slack/Teams/Email)
4) Add Workflow (tickets, broadcasts, webhooks, surveys, audit)
5) Launch pilot; measure and iterate

## Outcomes (headline copy)
- **Users**: Faster guidance, quick fixes, clear status
- **Teams**: More pipeline, fewer tickets, faster incidents, higher NRR
